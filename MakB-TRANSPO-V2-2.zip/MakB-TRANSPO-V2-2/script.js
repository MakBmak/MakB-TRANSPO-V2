const STORE = 'makb-transpo-v22';
const locNames = {H:'Home', UB:'Unit Base', ST:'SET'};
const todayKey = () => new Date().toISOString().slice(0,10);
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : 'id'+Date.now()+Math.random());
const $ = id => document.getElementById(id);

const defaultState = {
  settings:{timeHUB:15,timeUBST:15,drivers:[{id:uid(),name:'MK'},{id:uid(),name:'CY'}]},
  schedules:{}
};
let state = load();
let currentDate = todayKey();
let lastEditedId = null;

function sampleSchedule(){
  const [mk,cy]=state.settings.drivers;
  return [
    j('E','H','UB','06:55',mk.id), j('JOS','H','UB','08:10',mk.id), j('M','H','UB','08:45',mk.id), j('M & JOS','UB','ST','09:35',mk.id),
    j('ROS','H','UB','07:20',cy.id), j('JB','H','UB','07:50',cy.id), j('E','UB','ST','08:15',cy.id), j('JB & ROS','UB','ST','08:50',cy.id)
  ];
}
function j(passenger,from,to,time,driverId){return {id:uid(),passenger,from,to,time,driverId};}
function load(){try{return JSON.parse(localStorage.getItem(STORE)) || structuredClone(defaultState)}catch{return structuredClone(defaultState)}}
function save(){localStorage.setItem(STORE,JSON.stringify(state));}
function ensureDay(key){if(!state.schedules[key]) state.schedules[key]= key===todayKey()?sampleSchedule():[];}
function toMin(t){const [h,m]=t.split(':').map(Number);return h*60+m;}
function toTime(m){return `${String(Math.floor(m/60)%24).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;}
function duration(x){if((x.from==='H'&&x.to==='UB')||(x.from==='UB'&&x.to==='H'))return Number(state.settings.timeHUB);if((x.from==='UB'&&x.to==='ST')||(x.from==='ST'&&x.to==='UB'))return Number(state.settings.timeUBST);return Number(state.settings.timeHUB)+Number(state.settings.timeUBST)}
function endMin(x){return toMin(x.time)+duration(x)}
function endTime(x){return toTime(endMin(x))}
function overlaps(a,b){return toMin(a.time)<endMin(b)&&toMin(b.time)<endMin(a)}
function driverName(id){return state.settings.drivers.find(d=>d.id===id)?.name || 'Unknown'}
function isFree(driverId,trip,ignoreId=null){return !state.schedules[currentDate].some(x=>x.driverId===driverId && x.id!==ignoreId && overlaps(x,trip));}
function conflicts(){let out=[];const trips=state.schedules[currentDate];for(const d of state.settings.drivers){const list=trips.filter(x=>x.driverId===d.id);for(let a=0;a<list.length;a++)for(let b=a+1;b<list.length;b++)if(overlaps(list[a],list[b]))out.push([list[a],list[b],d]);}return out;}

function render(){ensureDay(currentDate);$('scheduleDate').value=currentDate;const diff=Math.round((new Date(currentDate)-new Date(todayKey()))/86400000);$('dayBadge').textContent=diff===0?'Today':diff===1?'Tomorrow Draft':diff<0?'Past':'Draft';
  const cons=conflicts(); const bad=new Set(); cons.forEach(([a,b])=>{bad.add(a.id);bad.add(b.id)});
  const grid=$('driversGrid');grid.innerHTML='';
  for(const d of state.settings.drivers){const card=document.createElement('section');card.className='driver-card';const hasConflict=state.schedules[currentDate].some(x=>x.driverId===d.id&&bad.has(x.id));card.innerHTML=`<div class="driver-head"><div class="driver-title">🚗 ${d.name}</div><div class="status ${hasConflict?'conflict':''}">${hasConflict?'Conflict 🔴':'Available ✅'}</div></div><div class="journeys"></div>`;const list=card.querySelector('.journeys');state.schedules[currentDate].filter(x=>x.driverId===d.id).sort((a,b)=>toMin(a.time)-toMin(b.time)).forEach(x=>{const btn=document.createElement('button');btn.id='trip-'+x.id;btn.className='journey '+(bad.has(x.id)?'conflict ':'')+(x.id===lastEditedId?'new-conflict':'');btn.innerHTML=`<div class="time">${x.time}</div><div><div class="route">${locNames[x.from]} → ${locNames[x.to]}</div><div class="arrive">Arrive ${endTime(x)}</div></div><div class="bubble">${x.passenger}</div>`;btn.onclick=()=>openJourney(x);list.appendChild(btn);});grid.appendChild(card);}
  renderWarning(cons);save();}
function renderWarning(cons){const w=$('warning'); if(!cons.length){w.classList.add('hidden');w.innerHTML='';return;} w.classList.remove('hidden');let [a,b,d]=cons[0];let newer= lastEditedId && (a.id===lastEditedId||b.id===lastEditedId) ? state.schedules[currentDate].find(x=>x.id===lastEditedId) : b;let old=newer.id===a.id?b:a;let fixes=state.settings.drivers.filter(dr=>dr.id!==newer.driverId&&isFree(dr.id,newer,newer.id));w.innerHTML=`🔴 <b>Conflict</b><br>${driverName(newer.driverId)} is double-booked.<br><br>Clash 1: <b>${old.passenger}</b> ${locNames[old.from]} → ${locNames[old.to]}, ${old.time}–${endTime(old)}<br>Clash 2: <b>${newer.passenger}</b> ${locNames[newer.from]} → ${locNames[newer.to]}, ${newer.time}–${endTime(newer)}<br><br>${fixes.length?fixes.map(f=>`<button onclick="moveTrip('${newer.id}','${f.id}')">Move ${newer.passenger} to ${f.name}</button>`).join(' '):'No other driver is free for this time.'}`;setTimeout(()=>document.getElementById('trip-'+old.id)?.scrollIntoView({behavior:'smooth',block:'center'}),80)}
window.moveTrip=(id,driverId)=>{state.schedules[currentDate]=state.schedules[currentDate].map(x=>x.id===id?{...x,driverId}:x);lastEditedId=id;render();}

function openJourney(x=null){$('journeyTitle').textContent=x?'Edit Journey':'Add Journey';$('journeyId').value=x?.id||'';$('passenger').value=x?.passenger||'';$('fromLoc').value=x?.from||'H';$('toLoc').value=x?.to||'UB';$('leaveTime').value=x?.time||'09:00';fillDriverSelect(x?.driverId);$('deleteJourney').classList.toggle('hidden',!x);$('journeyDialog').showModal();}
function fillDriverSelect(selected){$('driverSelect').innerHTML=state.settings.drivers.map(d=>`<option value="${d.id}" ${d.id===selected?'selected':''}>${d.name}</option>`).join('');}
$('journeyForm').addEventListener('submit',e=>{e.preventDefault();const id=$('journeyId').value||uid();const trip={id,passenger:$('passenger').value.trim(),from:$('fromLoc').value,to:$('toLoc').value,time:$('leaveTime').value,driverId:$('driverSelect').value};const exists=state.schedules[currentDate].some(x=>x.id===id);state.schedules[currentDate]=exists?state.schedules[currentDate].map(x=>x.id===id?trip:x):[...state.schedules[currentDate],trip];lastEditedId=id;$('journeyDialog').close();render();});
$('deleteJourney').onclick=()=>{state.schedules[currentDate]=state.schedules[currentDate].filter(x=>x.id!==$('journeyId').value);$('journeyDialog').close();lastEditedId=null;render();};$('cancelJourney').onclick=()=>$('journeyDialog').close();$('addJourney').onclick=()=>openJourney();

function openSettings(){ $('timeHUB').value=state.settings.timeHUB; $('timeUBST').value=state.settings.timeUBST; renderDriverSettings(); $('settingsDialog').showModal();}
function renderDriverSettings(){const box=$('driverSettings');box.innerHTML='';state.settings.drivers.forEach((d,i)=>{const row=document.createElement('div');row.className='driver-row';row.innerHTML=`<label>Driver ${i+1}<input data-driver-id="${d.id}" value="${d.name}"></label><button type="button" ${state.settings.drivers.length<=1?'disabled':''} onclick="removeDriver('${d.id}')">Remove</button>`;box.appendChild(row);});$('addDriverBtn').disabled=state.settings.drivers.length>=5;}
window.removeDriver=id=>{if(state.settings.drivers.length<=1)return;const replacement=state.settings.drivers.find(d=>d.id!==id)?.id;state.settings.drivers=state.settings.drivers.filter(d=>d.id!==id);Object.values(state.schedules).forEach(day=>day.forEach(x=>{if(x.driverId===id)x.driverId=replacement;}));renderDriverSettings();}
$('settingsForm').addEventListener('submit',e=>{e.preventDefault();state.settings.timeHUB=Number($('timeHUB').value)||15;state.settings.timeUBST=Number($('timeUBST').value)||15;document.querySelectorAll('[data-driver-id]').forEach(input=>{const d=state.settings.drivers.find(x=>x.id===input.dataset.driverId);if(d)d.name=input.value.trim()||d.name;});$('settingsDialog').close();render();});
$('addDriverBtn').onclick=()=>{if(state.settings.drivers.length<5){state.settings.drivers.push({id:uid(),name:'Driver '+(state.settings.drivers.length+1)});renderDriverSettings();}};$('settingsBtn').onclick=openSettings;$('cancelSettings').onclick=()=>$('settingsDialog').close();
$('scheduleDate').onchange=e=>{currentDate=e.target.value;lastEditedId=null;render();};$('prevDay').onclick=()=>shiftDay(-1);$('nextDay').onclick=()=>shiftDay(1);function shiftDay(n){const d=new Date(currentDate);d.setDate(d.getDate()+n);currentDate=d.toISOString().slice(0,10);lastEditedId=null;render();}
$('copyToday').onclick=()=>{if(currentDate===todayKey())return alert('You are already on today. Pick tomorrow or another date first.');ensureDay(todayKey());if(confirm('Copy today’s schedule to this day? This replaces this day.')){state.schedules[currentDate]=state.schedules[todayKey()].map(x=>({...x,id:uid()}));lastEditedId=null;render();}};$('clearDay').onclick=()=>{if(confirm('Clear all journeys for this day?')){state.schedules[currentDate]=[];lastEditedId=null;render();}};
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});render();
